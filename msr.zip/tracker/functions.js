

/*
functions.wait = function(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
};


functions.login = function() {
    try {
        roblox.setCookie(process.env.cookie);
    } catch (error) {
        console.log(error);
    }
}


const discord = require('discord.js');
const roblox = require('noblox.js');
const place = [
'https://media.discordapp.net/attachments/603286984844247047/820505676836372480/unknown.png?width=1440&height=623', 'https://media.discordapp.net/attachments/603286984844247047/820499681846362153/unknown.png?width=1440&height=625'
]
let gamepasses = require("./gamepasses.json");
let gamepassIdsMS1 = [];
for (const i in gamepasses["MS1"]) gamepassIdsMS1.push(gamepasses["MS1"][i].id);
const getRaiderPower = require("./gamepassesdata.js")
const trackerSettings = require('./trackerSettings');
const functions = {};

functions.wait = function(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
};


functions.login = function() {
    try {
        roblox.setCookie(process.env.cookie);
    } catch (error) {
        console.log(error);
    }
}
 empty for now as we are restarting
*/ 


 // Switching to the old embeds for further use
/* 
old embed for join

        let profileURL = 'https://roblox.com/users/' + data.userId + '/profile';
        let thumbnailURL = 'https://www.roblox.com/headshot-thumbnail/image?userId=' + data.userId + '&width=420&height=420&format=png';

        const embed = new discord.MessageEmbed()
            .setTitle("A player is now online!")
            .setThumbnail(thumbnailURL)
            .setImage(place[Math.floor(Math.random() * place.length)])
            .setColor("GREEN")
            .setDescription('[Click here to visit their profile!](' + profileURL + ')\n' + data.name + ' is now playing military simulator!')
            .addFields({
                name: 'Name',
                value: data.name,
                inline: true
            }, {
                name: 'Group',
                value: data.group,
                inline: true
            }, {
                name: 'Game:',
                value: data.game,
                inline: true
            })
            leave embed
                     const embed = new discord.MessageEmbed()
            .setColor("RED")
            .setTitle("A player left the game!")
            .setThumbnail(thumbnailURL)
                 .setImage(place[Math.floor(Math.random() * place.length)])
            .setDescription('[Click here to visit their profile!](' + profileURL + ')\n' + data.name + ' left the game!')
            .addFields({
                name: 'Name:',
                value: data.name,
                inline: true
            }, {
                name: 'Group:',
                value: data.group,
                inline: true
            }, {
                name: 'Game:',
                value: data.game,
                inline: true
            })
*/