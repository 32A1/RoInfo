/*
 * Package: 
 * Name: trackerSettings.js
 * Author: Alan and ignacio
 * Creation Date: 10/16/21
 * Copyright: Copyright applies. Created by Alan and ignacio. all people who see has permission to edit, execute and modify the code however distribution is prohibited.
 */

const trackerSettings = {};

trackerSettings.groups = [
    /*["Order of The Ninth's Revenge", 7033913],
    ["Hydra International", 2981881],
    ["Οrder of the Valkyrie", 10937425],
    ["[Tнe Iппeя Ciяcle]", 5691294],
    ["[DoJ] Department of Justice .", 8224374],
    ["[TC] The Commandos", 9723651],
    ["The Oasis international", 11956846]*/
    ['trashnaz', 4808054],
    ['The Red cuff guard', 4805062],
    ['Gay rifles', 4948472, 1],
];
trackerSettings.places = [
    ["Border v1", 2988554876]
    
];
trackerSettings.info = [
    ["895753712918724675"]
]
module.exports = trackerSettings;