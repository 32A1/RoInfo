module.exports = {
  
	bot: {
		prefix: ';',
		clientSecret: 'NzbIGuI8KgpPzWHXagdaEP7YVzUOL5Ce',
		clientID: '708988369891229746'
	},
	website: {
		protocol: 'https://',
		domain: 'msr.kurds.online',
		port: 8080,
	}
};
